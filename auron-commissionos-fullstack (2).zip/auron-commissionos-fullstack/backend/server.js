const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5001;

app.use(cors());
app.use(express.json());

// In-memory store for live demo & GitHub deployment readiness
let systemState = {
  scannerConfig: {
    upiId: 'kharika2137@oksbi',
    payeeName: 'K K Harika',
    bankName: 'Canara Bank 1750',
    merchantVpa: 'alphaauron.commissionos@okicici'
  },
  commissions: [
    { id: 'COM-101', associate: 'Kattamanchi Harika', tier: 'Enterprise', revenue: 125000, rate: 15, payout: 18750, status: 'Approved' },
    { id: 'COM-102', associate: 'Hima Bindu', tier: 'Business', revenue: 84000, rate: 12, payout: 10080, status: 'Paid' },
    { id: 'COM-103', associate: 'Arjun Nair', tier: 'Starter', revenue: 45000, rate: 10, payout: 4500, status: 'Pending' }
  ],
  users: [
    { id: 1, name: 'Kattamanchi Harika', role: 'Super Admin', email: 'harika.kattamanchi@alphaauron.com', status: 'Active' },
    { id: 2, name: 'Hima Bindu', role: 'Talent Forge Associate', email: 'himabindu@alphaauron.com', status: 'Active' }
  ],
  logs: [
    { id: 1, action: 'System Boot', user: 'System', timestamp: new Date().toISOString() },
    { id: 2, action: 'UPI Scanner Verified (kharika2137@oksbi)', user: 'Kattamanchi Harika', timestamp: new Date().toISOString() }
  ],
  subscriptions: []
};

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'Auron CommissionOS Backend', port: PORT });
});

// Get full state
app.get('/api/state', (req, res) => {
  res.json(systemState);
});

// Update scanner config (Module 12 Admin Edit)
app.put('/api/scanner', (req, res) => {
  systemState.scannerConfig = { ...systemState.scannerConfig, ...req.body };
  systemState.logs.unshift({
    id: Date.now(),
    action: `Updated UPI Scanner Config (${systemState.scannerConfig.upiId})`,
    user: 'Admin',
    timestamp: new Date().toISOString()
  });
  res.json({ success: true, scannerConfig: systemState.scannerConfig });
});

// Update commissions (Module 3/4 Admin Edit)
app.post('/api/commissions', (req, res) => {
  const newItem = { id: `COM-${100 + systemState.commissions.length + 1}`, ...req.body };
  systemState.commissions.push(newItem);
  systemState.logs.unshift({
    id: Date.now(),
    action: `Added Commission Record ${newItem.id}`,
    user: 'Admin',
    timestamp: new Date().toISOString()
  });
  res.json({ success: true, commissions: systemState.commissions });
});

app.put('/api/commissions/:id', (req, res) => {
  const { id } = req.params;
  systemState.commissions = systemState.commissions.map(c => c.id === id ? { ...c, ...req.body } : c);
  systemState.logs.unshift({
    id: Date.now(),
    action: `Edited Commission Record ${id}`,
    user: 'Admin',
    timestamp: new Date().toISOString()
  });
  res.json({ success: true, commissions: systemState.commissions });
});

// Record subscription payment (Module 12)
app.post('/api/subscriptions', (req, res) => {
  const txn = {
    txnId: req.body.txnId || 'pay_rzp_' + Math.random().toString(36).substring(2, 10),
    planName: req.body.planName,
    amount: req.body.amount,
    method: req.body.method,
    timestamp: new Date().toISOString()
  };
  systemState.subscriptions.unshift(txn);
  systemState.logs.unshift({
    id: Date.now(),
    action: `Subscription Purchased: ${txn.planName} (₹${txn.amount})`,
    user: 'Client',
    timestamp: txn.timestamp
  });
  res.json({ success: true, transaction: txn });
});

app.listen(PORT, () => {
  console.log(`✅ Auron CommissionOS Backend running cleanly on http://localhost:${PORT}`);
});
