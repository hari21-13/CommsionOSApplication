import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import ModuleTwelveSubscriptions from './components/modules/ModuleTwelveSubscriptions';
import {
  Edit3, Plus, Download, FileText, Award, ShieldCheck, CheckCircle, BarChart3, Users, Activity, CreditCard
} from 'lucide-react';

export default function App() {
  const [activeModule, setActiveModule] = useState(1);
  const [isAdmin, setIsAdmin] = useState(true);
  const [editingRowId, setEditingRowId] = useState(null);

  const [scannerConfig, setScannerConfig] = useState({
    upiId: 'kharika2137@oksbi',
    payeeName: 'K K Harika',
    bankName: 'Canara Bank 1750',
    merchantVpa: 'alphaauron.commissionos@okicici'
  });

  const [commissions, setCommissions] = useState([
    { id: 'COM-101', associate: 'Kattamanchi Harika', tier: 'Enterprise', revenue: 125000, rate: 15, payout: 18750, status: 'Approved' },
    { id: 'COM-102', associate: 'Hima Bindu', tier: 'Business', revenue: 84000, rate: 12, payout: 10080, status: 'Paid' },
    { id: 'COM-103', associate: 'Arjun Nair', tier: 'Starter', revenue: 45000, rate: 10, payout: 4500, status: 'Pending' }
  ]);

  const [subscriptions, setSubscriptions] = useState([]);

  useEffect(() => {
    fetch('/api/state')
      .then((res) => res.json())
      .then((data) => {
        if (data.scannerConfig) setScannerConfig(data.scannerConfig);
        if (data.commissions) setCommissions(data.commissions);
        if (data.subscriptions) setSubscriptions(data.subscriptions);
      })
      .catch(() => {});
  }, []);

  const handleCommissionEdit = (id, field, value) => {
    setCommissions((prev) =>
      prev.map((row) => {
        if (row.id !== id) return row;
        const updated = { ...row, [field]: field === 'revenue' || field === 'rate' ? Number(value) : value };
        updated.payout = Math.round((updated.revenue * updated.rate) / 100);
        return updated;
      })
    );
  };

  const handleExportCSV = () => {
    const headers = ['ID,Associate,Tier,Revenue,Rate(%),Payout,Status'];
    const rows = commissions.map(c => `${c.id},${c.associate},${c.tier},${c.revenue},${c.rate},${c.payout},${c.status}`);
    const blob = new Blob([[...headers, ...rows].join('\n')], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'auron-commissionos-export.csv';
    a.click();
  };

  const totalRevenue = commissions.reduce((sum, c) => sum + c.revenue, 0);
  const totalPayout = commissions.reduce((sum, c) => sum + c.payout, 0);

  return (
    <div className="min-h-screen bg-black text-white flex">
      {/* Permanent Left Sidebar with All 12 Modules */}
      <Sidebar activeModule={activeModule} setActiveModule={setActiveModule} isAdmin={isAdmin} />

      {/* Main Content Area (No Top Module Tabs) */}
      <main className="flex-1 ml-64 p-8 max-w-7xl mx-auto space-y-6">
        {/* Global Project Description Banner */}
        <div className="bg-gradient-to-r from-red-950/60 via-zinc-950 to-black border border-red-900/50 rounded-2xl p-5 shadow-xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="space-y-1 max-w-3xl">
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping"></span>
              <h2 className="text-sm font-black uppercase tracking-wider text-red-500">
                About Auron CommissionOS — Enterprise Full-Stack Suite
              </h2>
            </div>
            <p className="text-xs text-zinc-300 leading-relaxed">
              Auron CommissionOS streamlines multi-tier associate commission calculations, Excel/CSV ledger imports, automated PDF invoicing & certification, visual revenue analytics, and direct subscription checkouts via Razorpay, Google Pay, and PhonePe.
            </p>
          </div>
          <button
            onClick={() => setIsAdmin(!isAdmin)}
            className={`px-3.5 py-2 rounded-lg text-xs font-bold border transition-all flex-shrink-0 ${
              isAdmin
                ? 'bg-red-600 border-red-500 text-white shadow-lg shadow-red-950'
                : 'bg-zinc-900 border-zinc-700 text-zinc-300'
            }`}
          >
            {isAdmin ? 'Admin Controls: ON' : 'Client View: ON'}
          </button>
        </div>

        {/* Module 12: Subscriptions & Editable Scanners */}
        {activeModule === 12 && (
          <ModuleTwelveSubscriptions
            scannerConfig={scannerConfig}
            setScannerConfig={setScannerConfig}
            isAdmin={isAdmin}
            onRecordPayment={(rec) => setSubscriptions([rec, ...subscriptions])}
          />
        )}

        {/* Modules 1, 2, 3, 4: Core Dashboard, Auth, Excel Import/Export & Financial Breakdowns with Admin Edit */}
        {[1, 2, 3, 4].includes(activeModule) && (
          <div className="space-y-6">
            <div className="flex justify-between items-center border-b border-red-900/50 pb-4">
              <div>
                <h3 className="text-2xl font-black uppercase text-white">
                  {activeModule === 1 && 'Module 1: Executive Commission Dashboard'}
                  {activeModule === 2 && 'Module 2: Client & Admin Role Access Control'}
                  {activeModule === 3 && 'Module 3: Excel / CSV Data Ledger & Editor'}
                  {activeModule === 4 && 'Module 4: Financial Commission Breakdowns'}
                </h3>
                <p className="text-xs text-zinc-400">
                  Real-time commission tracking with inline Admin edit permissions across records.
                </p>
              </div>
              <div className="flex space-x-3">
                <button
                  onClick={handleExportCSV}
                  className="flex items-center space-x-2 bg-zinc-900 hover:bg-zinc-800 border border-red-900/50 px-4 py-2 rounded-lg text-xs font-bold text-red-400"
                >
                  <Download className="w-4 h-4" />
                  <span>Export CSV / Excel</span>
                </button>
                {isAdmin && (
                  <button
                    onClick={() =>
                      setCommissions([
                        ...commissions,
                        {
                          id: `COM-${101 + commissions.length}`,
                          associate: 'New Associate',
                          tier: 'Business',
                          revenue: 50000,
                          rate: 12,
                          payout: 6000,
                          status: 'Pending'
                        }
                      ])
                    }
                    className="flex items-center space-x-2 bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg text-xs font-bold text-white shadow-lg shadow-red-950"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Record</span>
                  </button>
                )}
              </div>
            </div>

            {/* KPI Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div className="bg-zinc-950 border border-red-900/40 p-5 rounded-2xl">
                <p className="text-xs text-zinc-400 uppercase font-bold">Total Gross Revenue</p>
                <p className="text-2xl font-black text-white mt-1">₹{totalRevenue.toLocaleString('en-IN')}</p>
              </div>
              <div className="bg-zinc-950 border border-red-900/40 p-5 rounded-2xl">
                <p className="text-xs text-zinc-400 uppercase font-bold">Total Commission Payout</p>
                <p className="text-2xl font-black text-red-500 mt-1">₹{totalPayout.toLocaleString('en-IN')}</p>
              </div>
              <div className="bg-zinc-950 border border-red-900/40 p-5 rounded-2xl">
                <p className="text-xs text-zinc-400 uppercase font-bold">Active Subscriptions</p>
                <p className="text-2xl font-black text-emerald-400 mt-1">{subscriptions.length + 14} Active</p>
              </div>
            </div>

            {/* Editable Commission Ledger Table */}
            <div className="bg-zinc-950 border border-red-900/40 rounded-2xl overflow-hidden">
              <table className="w-full text-left text-sm">
                <thead className="bg-red-950/40 text-red-400 text-xs uppercase border-b border-red-900/40">
                  <tr>
                    <th className="p-4">ID</th>
                    <th className="p-4">Associate</th>
                    <th className="p-4">Tier</th>
                    <th className="p-4">Revenue (₹)</th>
                    <th className="p-4">Rate (%)</th>
                    <th className="p-4">Payout (₹)</th>
                    <th className="p-4">Status</th>
                    {isAdmin && <th className="p-4 text-right">Admin Edit</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-900">
                  {commissions.map((row) => {
                    const editing = editingRowId === row.id;
                    return (
                      <tr key={row.id} className="hover:bg-zinc-900/50">
                        <td className="p-4 font-mono text-xs text-red-400">{row.id}</td>
                        <td className="p-4 font-semibold">
                          {editing ? (
                            <input
                              value={row.associate}
                              onChange={(e) => handleCommissionEdit(row.id, 'associate', e.target.value)}
                              className="bg-zinc-900 border border-red-600 rounded px-2 py-1 text-xs text-white"
                            />
                          ) : (
                            row.associate
                          )}
                        </td>
                        <td className="p-4 text-xs">{row.tier}</td>
                        <td className="p-4">
                          {editing ? (
                            <input
                              type="number"
                              value={row.revenue}
                              onChange={(e) => handleCommissionEdit(row.id, 'revenue', e.target.value)}
                              className="bg-zinc-900 border border-red-600 rounded px-2 py-1 text-xs text-white w-24"
                            />
                          ) : (
                            `₹${row.revenue.toLocaleString('en-IN')}`
                          )}
                        </td>
                        <td className="p-4">
                          {editing ? (
                            <input
                              type="number"
                              value={row.rate}
                              onChange={(e) => handleCommissionEdit(row.id, 'rate', e.target.value)}
                              className="bg-zinc-900 border border-red-600 rounded px-2 py-1 text-xs text-white w-16"
                            />
                          ) : (
                            `${row.rate}%`
                          )}
                        </td>
                        <td className="p-4 font-bold text-red-400">₹{row.payout.toLocaleString('en-IN')}</td>
                        <td className="p-4">
                          <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-red-950/60 text-red-300 border border-red-800">
                            {row.status}
                          </span>
                        </td>
                        {isAdmin && (
                          <td className="p-4 text-right">
                            <button
                              onClick={() => setEditingRowId(editing ? null : row.id)}
                              className="inline-flex items-center space-x-1 px-3 py-1 rounded bg-red-600 hover:bg-red-700 text-xs font-bold text-white"
                            >
                              <Edit3 className="w-3 h-3" />
                              <span>{editing ? 'Done' : 'Edit'}</span>
                            </button>
                          </td>
                        )}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Modules 5 to 11 Views */}
        {[5, 6, 7, 8, 9, 10, 11].includes(activeModule) && (
          <div className="bg-zinc-950 border border-red-900/40 rounded-2xl p-8 space-y-6">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
              <div className="flex items-center space-x-3">
                {activeModule === 5 && <BarChart3 className="w-6 h-6 text-red-500" />}
                {activeModule === 6 && <FileText className="w-6 h-6 text-red-500" />}
                {activeModule === 7 && <Award className="w-6 h-6 text-red-500" />}
                {[8, 9].includes(activeModule) && <CreditCard className="w-6 h-6 text-red-500" />}
                {activeModule === 10 && <Users className="w-6 h-6 text-red-500" />}
                {activeModule === 11 && <Activity className="w-6 h-6 text-red-500" />}
                <h3 className="text-xl font-black uppercase text-white">
                  Module {activeModule} Operational Workspace
                </h3>
              </div>
              <button
                onClick={() => setActiveModule(12)}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 rounded-lg text-xs font-bold text-white"
              >
                Go to Subscription & Scanner Checkout →
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {commissions.map((item) => (
                <div key={item.id} className="p-5 bg-zinc-900/60 border border-zinc-800 rounded-xl flex justify-between items-center">
                  <div>
                    <p className="text-xs text-red-400 font-mono">{item.id}</p>
                    <p className="font-bold text-white">{item.associate}</p>
                    <p className="text-xs text-zinc-400">Tier: {item.tier} • Payout: ₹{item.payout.toLocaleString('en-IN')}</p>
                  </div>
                  <button
                    onClick={() => window.print()}
                    className="px-3 py-1.5 bg-zinc-800 hover:bg-red-600 text-xs font-bold rounded-lg transition-colors"
                  >
                    Generate Document
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
