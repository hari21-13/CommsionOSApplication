import React, { useState } from 'react';
import { QrCode, CreditCard, Edit3, CheckCircle, ShieldCheck, Lock } from 'lucide-react';

export default function ModuleTwelveSubscriptions({ scannerConfig, setScannerConfig, isAdmin, onRecordPayment }) {
  const [selectedApp, setSelectedApp] = useState('gpay');
  const [isEditing, setIsEditing] = useState(false);
  const [planAmount, setPlanAmount] = useState('5999');
  const [planName, setPlanName] = useState('BUSINESS PLAN');
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState(null);

  const handleSaveConfig = async () => {
    setIsEditing(false);
    try {
      await fetch('/api/scanner', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(scannerConfig)
      });
    } catch (_) {
      // Offline fallback works seamlessly
    }
  };

  const handleSimulatedPayment = async () => {
    const txnId = 'pay_rzp_' + Math.random().toString(36).substring(2, 10);
    const record = {
      txnId,
      planName,
      amount: planAmount,
      method: `Razorpay / ${selectedApp.toUpperCase()} Gateway`
    };

    try {
      await fetch('/api/subscriptions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(record)
      });
    } catch (_) {}

    if (onRecordPayment) onRecordPayment(record);

    setPaymentStatus({
      method: record.method,
      id: txnId,
      time: new Date().toLocaleString()
    });
    setShowCheckoutModal(false);
  };

  return (
    <div className="space-y-8">
      {/* Header Bar */}
      <div className="border-b border-red-900/50 pb-5 flex flex-wrap gap-4 justify-between items-center">
        <div>
          <h3 className="text-2xl font-black tracking-wide text-white uppercase">
            Module 12: Subscriptions & Dynamic QR Scanners
          </h3>
          <p className="text-sm text-zinc-400">
            Purchase subscription tiers directly via Razorpay or scan merchant Google Pay / PhonePe QR codes.
          </p>
        </div>
        <button
          onClick={() => (isEditing ? handleSaveConfig() : setIsEditing(true))}
          className="flex items-center space-x-2 bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-lg shadow-red-950 transition-all"
        >
          <Edit3 className="w-4 h-4" />
          <span>{isEditing ? 'Save Scanner Changes' : 'Edit Scanner (GPay / PhonePe)'}</span>
        </button>
      </div>

      {paymentStatus && (
        <div className="p-4 bg-emerald-950/50 border border-emerald-500/50 rounded-xl flex items-center space-x-3 shadow-lg">
          <CheckCircle className="w-6 h-6 text-emerald-400 flex-shrink-0" />
          <div>
            <p className="font-bold text-emerald-300">
              Subscription Activated Successfully via {paymentStatus.method}!
            </p>
            <p className="text-xs text-emerald-400/80">
              Txn ID: {paymentStatus.id} | Timestamp: {paymentStatus.time}
            </p>
          </div>
        </div>
      )}

      {/* Main Grid: Plans Selection & Scanners */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Subscription Tiers */}
        <div className="bg-zinc-950 border border-red-900/40 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
            <h4 className="text-lg font-bold text-white flex items-center space-x-2">
              <ShieldCheck className="w-5 h-5 text-red-500" />
              <span>Subscription Plans</span>
            </h4>
            <span className="bg-red-950 text-red-400 text-xs px-2.5 py-1 rounded-full font-semibold border border-red-800">
              Direct Checkout
            </span>
          </div>

          <div className="space-y-4">
            {[
              { name: 'STARTER COMMISSION TIER', price: '2,499', raw: '2499', desc: 'Standard commission splits, CSV/Excel export & ledger tracking' },
              { name: 'BUSINESS PLAN', price: '5,999', raw: '5999', desc: 'Full 12-module access, PDF invoices, certificates & Razorpay sync' },
              { name: 'ENTERPRISE UNLIMITED', price: '12,999', raw: '12999', desc: 'Unlimited team seats, custom VPA scanners & priority SLA' }
            ].map((plan, idx) => (
              <div
                key={idx}
                onClick={() => {
                  setPlanName(plan.name);
                  setPlanAmount(plan.raw);
                }}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  planName === plan.name
                    ? 'bg-red-950/30 border-red-600 shadow-lg shadow-red-950'
                    : 'bg-zinc-900/40 border-zinc-800 hover:border-red-900'
                }`}
              >
                <div className="flex justify-between items-center gap-4">
                  <div>
                    <h5 className="font-bold text-white">{plan.name}</h5>
                    <p className="text-xs text-zinc-400 mt-0.5">{plan.desc}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <span className="text-lg font-black text-red-500">₹{plan.price}</span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setPlanName(plan.name);
                        setPlanAmount(plan.raw);
                        setShowCheckoutModal(true);
                      }}
                      className="block mt-2 px-3.5 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-bold shadow"
                    >
                      Buy Plan
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={() => setShowCheckoutModal(true)}
            className="w-full py-3.5 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-500 hover:to-red-600 text-white rounded-xl font-bold tracking-wide shadow-lg shadow-red-900/60 transition-all flex items-center justify-center space-x-2"
          >
            <CreditCard className="w-5 h-5" />
            <span>Proceed to Razorpay Checkout (₹{planAmount})</span>
          </button>
        </div>

        {/* Live Scanner Hub (GPay & PhonePe) */}
        <div className="bg-zinc-950 border border-red-900/40 rounded-2xl p-6 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
            <h4 className="text-lg font-bold text-white flex items-center space-x-2">
              <QrCode className="w-5 h-5 text-red-500" />
              <span>GPay & PhonePe Scanner</span>
            </h4>
            <div className="flex space-x-2">
              <button
                onClick={() => setSelectedApp('gpay')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  selectedApp === 'gpay' ? 'bg-red-600 text-white' : 'bg-zinc-900 text-zinc-400 hover:text-white'
                }`}
              >
                Google Pay
              </button>
              <button
                onClick={() => setSelectedApp('phonepe')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  selectedApp === 'phonepe' ? 'bg-red-600 text-white' : 'bg-zinc-900 text-zinc-400 hover:text-white'
                }`}
              >
                PhonePe
              </button>
            </div>
          </div>

          {/* Scanner Card */}
          <div className="bg-white text-zinc-900 rounded-2xl p-6 shadow-2xl max-w-sm mx-auto space-y-4 relative border-4 border-red-600/40">
            <div className="text-center">
              <span
                className={`inline-block px-3 py-1 rounded-full text-xs font-extrabold text-white ${
                  selectedApp === 'gpay' ? 'bg-blue-600' : 'bg-emerald-600'
                }`}
              >
                {selectedApp === 'gpay' ? 'Scan to pay with Google Pay' : '✓ Receiving money on PhonePe'}
              </span>
            </div>

            <div className="flex items-center justify-center space-x-2">
              <div className="w-8 h-8 rounded-full bg-orange-600 text-white font-bold flex items-center justify-center text-sm">
                {scannerConfig.payeeName.charAt(0)}
              </div>
              {isEditing ? (
                <input
                  type="text"
                  value={scannerConfig.payeeName}
                  onChange={(e) => setScannerConfig({ ...scannerConfig, payeeName: e.target.value })}
                  className="border border-zinc-400 rounded px-2 py-0.5 text-sm font-bold text-black"
                />
              ) : (
                <span className="font-extrabold text-lg text-zinc-900">{scannerConfig.payeeName}</span>
              )}
            </div>

            {/* Crisp SVG QR Code Matrix */}
            <div className="bg-zinc-50 p-4 rounded-xl border border-zinc-200 flex flex-col items-center justify-center relative">
              <div className="w-48 h-48 bg-white p-2 rounded-lg flex items-center justify-center relative border border-zinc-300 shadow-inner">
                <svg viewBox="0 0 100 100" className="w-full h-full fill-zinc-900">
                  <rect x="5" y="5" width="25" height="25" fill="none" stroke="#18181b" strokeWidth="5" />
                  <rect x="12" y="12" width="11" height="11" />
                  <rect x="70" y="5" width="25" height="25" fill="none" stroke="#18181b" strokeWidth="5" />
                  <rect x="77" y="12" width="11" height="11" />
                  <rect x="5" y="70" width="25" height="25" fill="none" stroke="#18181b" strokeWidth="5" />
                  <rect x="12" y="77" width="11" height="11" />
                  <rect x="38" y="8" width="6" height="6" />
                  <rect x="50" y="14" width="8" height="8" />
                  <rect x="38" y="24" width="10" height="6" />
                  <rect x="10" y="40" width="8" height="8" />
                  <rect x="24" y="46" width="10" height="6" />
                  <rect x="68" y="40" width="10" height="8" />
                  <rect x="84" y="48" width="8" height="10" />
                  <rect x="40" y="68" width="8" height="8" />
                  <rect x="56" y="72" width="10" height="6" />
                  <rect x="72" y="70" width="8" height="10" />
                  <rect x="84" y="84" width="10" height="10" />
                  <rect x="42" y="86" width="14" height="6" />
                </svg>
                <div
                  className={`absolute w-11 h-11 rounded-full border-2 border-white flex items-center justify-center font-black text-base shadow-md ${
                    selectedApp === 'gpay' ? 'bg-white text-blue-600' : 'bg-black text-white'
                  }`}
                >
                  {selectedApp === 'gpay' ? 'G' : 'पे'}
                </div>
              </div>
              <p className="text-[11px] text-zinc-500 mt-2 font-medium">Scan to pay with any UPI app</p>
            </div>

            <div className="space-y-2 bg-zinc-50 p-3 rounded-xl border border-zinc-200 text-xs">
              <div className="flex justify-between items-center text-zinc-700 font-semibold">
                <span>Bank Account:</span>
                {isEditing ? (
                  <input
                    type="text"
                    value={scannerConfig.bankName}
                    onChange={(e) => setScannerConfig({ ...scannerConfig, bankName: e.target.value })}
                    className="border border-zinc-300 rounded px-1.5 py-0.5 text-xs text-black"
                  />
                ) : (
                  <span>{scannerConfig.bankName}</span>
                )}
              </div>
              <div className="flex justify-between items-center text-zinc-700 font-semibold">
                <span>UPI ID:</span>
                {isEditing ? (
                  <input
                    type="text"
                    value={scannerConfig.upiId}
                    onChange={(e) => setScannerConfig({ ...scannerConfig, upiId: e.target.value })}
                    className="border border-zinc-300 rounded px-1.5 py-0.5 text-xs text-black font-mono"
                  />
                ) : (
                  <span className="font-mono text-red-600 font-bold">{scannerConfig.upiId}</span>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Razorpay Secure Checkout Modal */}
      {showCheckoutModal && (
        <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-950 border border-red-900/60 rounded-3xl p-6 max-w-md w-full shadow-2xl relative space-y-5 text-white">
            <button
              onClick={() => setShowCheckoutModal(false)}
              className="absolute top-4 right-4 text-zinc-400 hover:text-white font-bold text-lg"
            >
              ✕
            </button>

            <div className="text-center space-y-2">
              <div className="inline-flex items-center space-x-2 bg-zinc-900 border border-zinc-700 px-3.5 py-1 rounded-full text-xs font-bold text-sky-400">
                <Lock className="w-3.5 h-3.5" />
                <span>Razorpay Secure Checkout</span>
              </div>
              <h4 className="text-xl font-black uppercase tracking-wider text-white">{planName}</h4>
              <p className="text-3xl font-black text-red-500">₹{Number(planAmount).toLocaleString('en-IN')}</p>
              <p className="text-xs text-zinc-400">
                Scan QR code using Razorpay or complete instant verification below.
              </p>
            </div>

            <div className="bg-white p-5 rounded-2xl flex flex-col items-center justify-center space-y-2 shadow-inner max-w-[230px] mx-auto">
              <QrCode className="w-28 h-28 text-zinc-900" />
              <p className="text-[11px] text-zinc-800 font-extrabold tracking-wide">ALPHA AURON MERCHANT QR</p>
            </div>

            <div className="text-center">
              <p className="text-xs font-mono text-red-400 font-bold">
                Merchant VPA: {scannerConfig.merchantVpa}
              </p>
            </div>

            <button
              onClick={handleSimulatedPayment}
              className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold tracking-wide shadow-lg shadow-emerald-950 transition-all flex items-center justify-center space-x-2"
            >
              <CheckCircle className="w-5 h-5" />
              <span>Simulate & Confirm Payment Success</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
