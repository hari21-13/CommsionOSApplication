import React from 'react';
import {
  LayoutDashboard, Users, Calculator, BarChart3, FileText, Award,
  CreditCard, ShieldCheck, Database, Settings, Activity, Wallet
} from 'lucide-react';

const MODULES = [
  { id: 1, name: 'Dashboard', icon: LayoutDashboard },
  { id: 2, name: 'Client & Admin Auth', icon: ShieldCheck },
  { id: 3, name: 'Excel Import/Export', icon: Database },
  { id: 4, name: 'Financial Breakdowns', icon: Calculator },
  { id: 5, name: 'Visual Analytics', icon: BarChart3 },
  { id: 6, name: 'PDF Invoice Gen', icon: FileText },
  { id: 7, name: 'Certificate Generator', icon: Award },
  { id: 8, name: 'Razorpay Gateway', icon: CreditCard },
  { id: 9, name: 'PhonePe & GPay', icon: Wallet },
  { id: 10, name: 'User Management', icon: Users },
  { id: 11, name: 'System Logs', icon: Activity },
  { id: 12, name: 'Subscriptions & Scanner', icon: Settings },
];

export default function Sidebar({ activeModule, setActiveModule, isAdmin }) {
  return (
    <aside className="w-64 bg-black border-r border-red-900/50 flex flex-col h-screen fixed left-0 top-0 text-white shadow-2xl z-50">
      {/* App Branding */}
      <div className="p-5 border-b border-red-900/40 flex items-center space-x-3 bg-gradient-to-r from-red-950/50 to-black">
        <div className="w-9 h-9 rounded-lg bg-red-600 flex items-center justify-center font-black text-lg shadow-lg shadow-red-600/50">
          C
        </div>
        <div>
          <h1 className="font-extrabold tracking-wider text-red-500 text-base">CommissionOS</h1>
          <p className="text-[11px] text-zinc-400">Alpha Auron Enterprise</p>
        </div>
      </div>

      {/* 12 Modules Navigation List */}
      <nav className="flex-1 overflow-y-auto py-3 px-3 space-y-1 custom-scrollbar">
        <div className="px-3 pb-1.5 text-[10px] font-bold uppercase tracking-wider text-red-400">
          All 12 Modules
        </div>
        {MODULES.map((mod) => {
          const Icon = mod.icon;
          const isActive = activeModule === mod.id;
          return (
            <button
              key={mod.id}
              onClick={() => setActiveModule(mod.id)}
              className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all duration-200 ${
                isActive
                  ? 'bg-red-600 text-white shadow-md shadow-red-900/50 border-l-4 border-white'
                  : 'text-zinc-300 hover:bg-red-950/40 hover:text-red-400'
              }`}
            >
              <Icon className={`w-4 h-4 flex-shrink-0 ${isActive ? 'text-white' : 'text-red-500'}`} />
              <span className="truncate">
                {mod.id}. {mod.name}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Footer User Info */}
      <div className="p-4 border-t border-red-900/40 bg-zinc-950 text-xs text-zinc-400 flex items-center justify-between">
        <div>
          <p className="font-semibold text-zinc-200">Kattamanchi Harika</p>
          <p className="text-[10px] text-red-400">{isAdmin ? 'Admin Mode Active' : 'Client View Mode'}</p>
        </div>
        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" title="Backend Connected"></span>
      </div>
    </aside>
  );
}
