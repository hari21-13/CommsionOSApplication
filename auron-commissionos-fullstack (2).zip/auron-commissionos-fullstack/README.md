# Auron CommissionOS — Full-Stack Enterprise Commission & Subscription Management Platform

**Auron CommissionOS** is a 12-module full-stack enterprise platform built for **Alpha Auron Private Limited**, featuring a high-contrast **Black & Red** UI, permanent left-sidebar navigation across all 12 modules, role-based Admin edit controls, Excel/CSV data pipelines, PDF invoice & certificate generation, and integrated Razorpay, Google Pay, and PhonePe subscription checkout scanners.

## Quick Start

### 1. Start Backend Server (Port 5001)
```bash
cd backend
npm install
node server.js
```

### 2. Start Frontend Application (Port 5173)
```bash
cd frontend
npm install
npm run dev
```
